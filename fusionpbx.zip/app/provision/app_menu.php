<?php

	//$apps[$x]['menu'][0]['title']['en-us'] = "Provision";
	//$apps[$x]['menu'][0]['title']['en-gb'] = "Provision";
	//$apps[$x]['menu'][0]['title']['fr-fr'] = "Provision";
	//$apps[$x]['menu'][0]['title']['ru-ru'] = "Обеспечение";
	//$apps[$x]['menu'][0]['title']['de-de'] = "Bereitstellung";
	//$apps[$x]['menu'][0]['title']['de-at'] = "Bereitstellung";
	//$apps[$x]['menu'][0]['uuid'] = "";
	//$apps[$x]['menu'][0]['parent_uuid'] = "";
	//$apps[$x]['menu'][0]['category'] = "internal";
	//$apps[$x]['menu'][0]['path'] = "";
	//$apps[$x]['menu'][0]['groups'][] = "admin";
	//$apps[$x]['menu'][0]['groups'][] = "superadmin";

?>
