<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Time Conditions";
	$apps[$x]['menu'][$y]['title']['en-gb'] = "Time Conditions";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Zeitschaltung";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Zeitschaltung";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Condic. de Tiempo";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Conditions Temporelles";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Condizioni Temporali";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Warunki czasowe";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Condições temporarias";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Condições Temporais";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Условия по времени";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Tidsstyrning";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Часові умови";
	$apps[$x]['menu'][$y]['uuid'] = "67aede56-8623-df2d-6338-ecfbde5825f7";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/time_conditions/time_conditions.php";
	$apps[$x]['menu'][$y]['groups'][] = "admin";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>