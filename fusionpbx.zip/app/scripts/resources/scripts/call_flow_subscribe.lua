-- For backward compatibility
argv[1] = 'flow'
require "blf_subscribe"

