<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Outbound Routes";
	$apps[$x]['menu'][$y]['title']['en-gb'] = "Outbound Routes";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Ausgehendes Routing";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Ausgehendes Routing";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Rutas de salida";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "Rutas de salida";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Routes Sortantes";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Rotte di Uscita";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "Uitgaande routering";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Trasy wyjściowe";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Rotas de Saída";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Маршрутизация исходящих";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Вихідні маршрути";
	$apps[$x]['menu'][$y]['uuid'] = "17e14094-1d57-1106-db2a-a787d34015e9";
	$apps[$x]['menu'][$y]['parent_uuid'] = "b94e8bd9-9eb5-e427-9c26-ff7a6c21552a";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/dialplans/dialplans.php?app_uuid=8c914ec3-9fc0-8ab5-4cda-6c9288bdc9a3";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>
