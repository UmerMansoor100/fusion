<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Recordings";
	$apps[$x]['menu'][$y]['title']['en-gb'] = "Recordings";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Aufnahmen";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Aufnahmen";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Grabaciones";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "Guides vocaux";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Guides vocaux";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Registrazioni Audio";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "Opnamen";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Nagrywanie rozmów";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Gravações";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Gravações";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Записи";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Inspelningar";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Записи";
	$apps[$x]['menu'][$y]['uuid'] = "e4290fd2-3ccc-a758-1714-660d38453104";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/recordings/recordings.php";
	$apps[$x]['menu'][$y]['groups'][] = "admin";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>
