<?php
		//application details
                $apps[$x]['name'] = "Swissvoice";
                $apps[$x]['uuid'] = "8848902f-2007-4b11-b9f9-58bdef32df64";
                $apps[$x]['category'] = "Vendor";
                $apps[$x]['subcategory'] = "";
                $apps[$x]['version'] = "1.0";
                $apps[$x]['license'] = "Mozilla Public License 1.1";
                $apps[$x]['url'] = "http://www.fusionpbx.com";
                $apps[$x]['description']['en-us'] = "";
                $apps[$x]['description']['en-gb'] = "";
                $apps[$x]['description']['ar-eg'] = "";
                $apps[$x]['description']['de-at'] = "";
                $apps[$x]['description']['de-ch'] = "";
                $apps[$x]['description']['de-de'] = "";
                $apps[$x]['description']['es-cl'] = "";
                $apps[$x]['description']['es-mx'] = "";
                $apps[$x]['description']['fr-ca'] = "";
                $apps[$x]['description']['fr-fr'] = "";
                $apps[$x]['description']['he-il'] = "";
                $apps[$x]['description']['it-it'] = "";
                $apps[$x]['description']['nl-nl'] = "";
                $apps[$x]['description']['pl-pl'] = "";
                $apps[$x]['description']['pt-br'] = "";
                $apps[$x]['description']['pt-pt'] = "";
                $apps[$x]['description']['ro-ro'] = "";
                $apps[$x]['description']['ru-ru'] = "";
                $apps[$x]['description']['sv-se'] = "";
                $apps[$x]['description']['uk-ua'] = "";

		//default settings
		$y=0;
		$apps[$x]['default_settings'][$y]['default_setting_uuid'] = "307e4444-1a75-4f32-b494-cff6a3f9308e";
		$apps[$x]['default_settings'][$y]['default_setting_category'] = "provision";
		$apps[$x]['default_settings'][$y]['default_setting_subcategory'] = "swissvoice_codec_order";
		$apps[$x]['default_settings'][$y]['default_setting_name'] = "text";
		$apps[$x]['default_settings'][$y]['default_setting_value'] = "PCMU,PCMA,G726-32,G729,G723,iLBC,AMR,G722,AMR-WB";
		$apps[$x]['default_settings'][$y]['default_setting_enabled'] = "false";
		$apps[$x]['default_settings'][$y]['default_setting_description'] = "Separatea by comma. Default = PCMU,PCMA,G726-32,G729,G723,iLBC,AMR,G722,AMR-WB";
		$y++;
?>
