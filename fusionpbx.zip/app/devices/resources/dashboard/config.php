<?php

$array['dashboard'][$x]['dashboard_uuid'] = 'f1c722d5-b714-4fa2-9664-5f6d24d44661';
$array['dashboard'][$x]['dashboard_name'] = 'Device Keys';
$array['dashboard'][$x]['dashboard_path'] = 'app/devices/resources/dashboard/device_keys.php';
$array['dashboard'][$x]['dashboard_order'] = '150';
$array['dashboard'][$x]['dashboard_enabled'] = 'false';
$array['dashboard'][$x]['dashboard_description'] = '';
$y = 0;
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_group_uuid'] = '0d04d50e-aa49-40d2-9e98-ed21f9070f6f';
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_uuid'] = 'f1c722d5-b714-4fa2-9664-5f6d24d44661';
$array['dashboard'][$x]['dashboard_groups'][$y]['group_name'] = 'user';

?>
