<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Devices";
	$apps[$x]['menu'][$y]['title']['en-gb'] = "Devices";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Geräte";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Geräte";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Dispositivos";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "Dispositivos";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "Dispositifs";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Equipements";
	$apps[$x]['menu'][$y]['title']['he-il'] = "התקנים";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Dispositivi";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "Toestellen";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Urządzenia";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Telefones IP";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Telefones";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "Dispozitive";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Устройства";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Enheter";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Пристрої";
	$apps[$x]['menu'][$y]['uuid'] = "f9dce498-b7f9-740f-e592-9e8ff3dac2a0";
	$apps[$x]['menu'][$y]['parent_uuid'] = "bc96d773-ee57-0cdd-c3ac-2d91aba61b55";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/devices/devices.php";
	$apps[$x]['menu'][$y]['groups'][] = "admin";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>
