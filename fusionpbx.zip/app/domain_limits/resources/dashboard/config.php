<?php

$array['dashboard'][$x]['dashboard_uuid'] = '2f7a90cc-8d60-4df4-98ee-2ef4000afac7';
$array['dashboard'][$x]['dashboard_name'] = 'Domain Limits';
$array['dashboard'][$x]['dashboard_path'] = 'app/domain_limits/resources/dashboard/domain_limits.php';
$array['dashboard'][$x]['dashboard_order'] = '120';
$array['dashboard'][$x]['dashboard_enabled'] = 'false';
$array['dashboard'][$x]['dashboard_description'] = '';
$y = 0;
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_group_uuid'] = 'e99eb62e-4150-42a8-8c0c-4a264245f12a';
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_uuid'] = '2f7a90cc-8d60-4df4-98ee-2ef4000afac7';
$array['dashboard'][$x]['dashboard_groups'][$y]['group_name'] = 'superadmin';
$y++;
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_group_uuid'] = 'db7c3c71-9761-4bd9-a166-ea5a0de2cd0e';
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_uuid'] = '2f7a90cc-8d60-4df4-98ee-2ef4000afac7';
$array['dashboard'][$x]['dashboard_groups'][$y]['group_name'] = 'admin';
$y++;
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_group_uuid'] = 'b8772e85-bcbd-4e8c-afba-e9c04a700bfa';
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_uuid'] = '2f7a90cc-8d60-4df4-98ee-2ef4000afac7';
$array['dashboard'][$x]['dashboard_groups'][$y]['group_name'] = 'user';

?>
