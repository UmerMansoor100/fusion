<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Number Translations";
	$apps[$x]['menu'][$y]['title']['en-gb'] = "Number Translations";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "عدد الترجمة"; //Google translate
	$apps[$x]['menu'][$y]['title']['de-at'] = "Nummer Übersetzung";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "Nummer Übersetzung";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Nummer Übersetzung";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Traducción de números"; //Google translate
	$apps[$x]['menu'][$y]['title']['es-mx'] = "Traducción de números"; //Google translate
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "Traduction de numéros"; //Google translate
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Traduction de numéros"; //Google translate
	$apps[$x]['menu'][$y]['title']['he-il'] = "תרגום מספר"; //Google translate
	$apps[$x]['menu'][$y]['title']['it-it'] = "Traduzione numero"; //Google translate
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "Nummer Vertaling"; //Google translate
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Tłumaczenie liczbowe"; //Google translate
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Tradução numérica"; //Google translate
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Tradução numérica"; //Google translate
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "Traducerea numerelor"; //Google translate
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Преобразование номера";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Antal översättning"; //Google translate
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "кількість перекладів"; //Google translate
	$apps[$x]['menu'][$y]['uuid'] = "6ad5505c-4909-11e7-a919-92ebcb67fe33";
	$apps[$x]['menu'][$y]['parent_uuid'] = "594d99c5-6128-9c88-ca35-4b33392cec0f";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/number_translations/number_translations.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>
