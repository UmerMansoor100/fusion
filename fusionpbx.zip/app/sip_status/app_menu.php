<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "SIP Status";
	$apps[$x]['menu'][$y]['title']['en-gb'] = "SIP Status";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "SIP Status";
	$apps[$x]['menu'][$y]['title']['de-de'] = "SIP Status";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Estado de SIP";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Statut SIP";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Stato SIP";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "SIP Status";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Status SIP";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Estado do SIP";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Estado do SIP";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Статус SIP";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "SIP Status";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Стан SIP";
	$apps[$x]['menu'][$y]['uuid'] = "b7aea9f7-d3cf-711f-828e-46e56e2e5328";
	$apps[$x]['menu'][$y]['parent_uuid'] = "0438b504-8613-7887-c420-c837ffb20cb1";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/sip_status/sip_status.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>
