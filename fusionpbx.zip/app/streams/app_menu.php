<?php

$apps[$x]['menu'][0]['title']['en-us'] = 'Streams';
$apps[$x]['menu'][0]['title']['en-gb'] = 'Streams';
$apps[$x]['menu'][0]['title']['es-cl'] = '';
$apps[$x]['menu'][0]['title']['fr-fr'] = '';
$apps[$x]['menu'][0]['title']['fr-ca'] = '';
$apps[$x]['menu'][0]['title']['pl'] = '';
$apps[$x]['menu'][0]['title']['sv-se'] = '';
$apps[$x]['menu'][0]['title']['uk'] = '';
$apps[$x]['menu'][0]['title']['de-at'] = '';
$apps[$x]['menu'][0]['uuid'] = 'c9762b7a-a809-444c-96db-f80f0c2bb36f';
$apps[$x]['menu'][0]['parent_uuid'] = 'fd29e39c-c936-f5fc-8e2b-611681b266b5';
$apps[$x]['menu'][0]['category'] = 'internal';
$apps[$x]['menu'][0]['path'] = '/app/streams/streams.php';
$apps[$x]['menu'][0]['groups'][] = 'superadmin';
//$apps[$x]['menu'][0]['groups'][] = 'admin';
//$apps[$x]['menu'][0]['groups'][] = 'user';

?>
