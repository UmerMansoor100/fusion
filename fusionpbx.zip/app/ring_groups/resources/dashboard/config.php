<?php

$array['dashboard'][$x]['dashboard_uuid'] = 'b5da1d72-2cc7-422e-b05c-f07659aed419';
$array['dashboard'][$x]['dashboard_name'] = 'Ring Group Forward';
$array['dashboard'][$x]['dashboard_path'] = 'app/ring_groups/resources/dashboard/ring_group_forward.php';
$array['dashboard'][$x]['dashboard_order'] = '140';
$array['dashboard'][$x]['dashboard_enabled'] = 'true';
$array['dashboard'][$x]['dashboard_description'] = 'Used for updating ring group call forward.';
$y = 0;
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_group_uuid'] = '7aa0fdf0-100a-4ee3-ae37-67cb9a021493';
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_uuid'] = 'b5da1d72-2cc7-422e-b05c-f07659aed419';
$array['dashboard'][$x]['dashboard_groups'][$y]['group_name'] = 'superadmin';
$y++;
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_group_uuid'] = '10ec859b-2325-4d66-92ce-410da9e1ee62';
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_uuid'] = 'b5da1d72-2cc7-422e-b05c-f07659aed419';
$array['dashboard'][$x]['dashboard_groups'][$y]['group_name'] = 'admin';
$y++;
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_group_uuid'] = 'f7ef37b1-8134-48d1-b25a-d1a50bf0e339';
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_uuid'] = 'b5da1d72-2cc7-422e-b05c-f07659aed419';
$array['dashboard'][$x]['dashboard_groups'][$y]['group_name'] = 'user';

?>
