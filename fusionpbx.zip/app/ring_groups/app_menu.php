<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Ring Groups";
	$apps[$x]['menu'][$y]['title']['en-gb'] = "Ring Groups";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Rufgruppen";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Rufgruppen";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Grupo de llamados";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Groupes de sonnerie";
	$apps[$x]['menu'][$y]['title']['he-il'] = "קבוצות חיוג";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Gruppi di Squillo";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "Bel groepen";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Grupy odbiorców rozmów.";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Grupos de chamada";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Grupos de Ring";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Группы вызовов";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Ringgrupper";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Групи";
	$apps[$x]['menu'][$y]['uuid'] = "b30f085f-3ec6-2819-7e62-53dfba5cb8d5";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/ring_groups/ring_groups.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";
	$apps[$x]['menu'][$y]['groups'][] = "admin";

?>
