<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Phrases";
	$apps[$x]['menu'][$y]['title']['en-gb'] = "Phrases";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Phrasen";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Phrasen";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Grabaciones";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Guides Vocaux";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Frasi";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "Uitspraken";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Zwroty";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Gravações";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Gravações";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Фразы";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Fraser";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Фрази";

	$apps[$x]['menu'][$y]['uuid'] = "a5caa6dc-a6d7-41c3-a484-e556ffd0d2ff";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/phrases/phrases.php";
	$apps[$x]['menu'][$y]['groups'][] = "admin";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>
