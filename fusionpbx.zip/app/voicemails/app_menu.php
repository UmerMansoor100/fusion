<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Voicemail";
	$apps[$x]['menu'][$y]['title']['en-gb'] = "Voicemail";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Sprachnachrichten";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Sprachnachrichten";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Messagerie Vocale";
	$apps[$x]['menu'][$y]['title']['he-il'] = "תא קולי";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Caselle Vocali";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "Antwoordapparaat";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Poczta głosowa";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Correio de voz";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Голосовая почта";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Röstbrevlåda";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Голосова пошта";
	$apps[$x]['menu'][$y]['uuid'] = "0347f82a-62a0-49d0-bacd-511d080c46d5";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/voicemails/voicemails.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";
	$apps[$x]['menu'][$y]['groups'][] = "admin";

?>
