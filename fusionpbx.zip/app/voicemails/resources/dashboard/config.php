<?php

$array['dashboard'][$x]['dashboard_uuid'] = 'be2aaa22-d8f1-4d9b-b5f9-14a26da329cb';
$array['dashboard'][$x]['dashboard_name'] = 'New Messages';
$array['dashboard'][$x]['dashboard_path'] = 'app/voicemails/resources/dashboard/voicemails.php';
$array['dashboard'][$x]['dashboard_order'] = '20';
$array['dashboard'][$x]['dashboard_enabled'] = 'true';
$array['dashboard'][$x]['dashboard_description'] = 'Count the new voicemail messages and list of assigned voicemail boxes.';
$y = 0;
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_group_uuid'] = '05466c38-88cd-456c-98cd-4cbf323af04f';
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_uuid'] = 'be2aaa22-d8f1-4d9b-b5f9-14a26da329cb';
$array['dashboard'][$x]['dashboard_groups'][$y]['group_name'] = 'superadmin';
$y++;
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_group_uuid'] = '5320e3a7-255e-49b0-9ff5-172f590dcdf1';
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_uuid'] = 'be2aaa22-d8f1-4d9b-b5f9-14a26da329cb';
$array['dashboard'][$x]['dashboard_groups'][$y]['group_name'] = 'admin';
$y++;
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_group_uuid'] = '9052c80b-802f-4111-baa4-202a41ec7ffc';
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_uuid'] = 'be2aaa22-d8f1-4d9b-b5f9-14a26da329cb';
$array['dashboard'][$x]['dashboard_groups'][$y]['group_name'] = 'user';

?>
