<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Call Block";
	$apps[$x]['menu'][$y]['title']['en-gb'] = "Call Block";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "حظر المكالمات";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Sperrlisten";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Sperrlisten";
	$apps[$x]['menu'][$y]['title']['el-gr'] = "Λίστα απορρίψεων";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Bloqueo de llamadas";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Liste Noire";
	$apps[$x]['menu'][$y]['title']['he-il'] = "חסימת מספר";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Blocco Chiamate";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "Oproep blokkade";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Blokowanie rozmów";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Bloqueio de chamadas";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Bloqueio de Chamadas";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "Blocare apel";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Черный список";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Blockera Samtal";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Блокування дзвінків";
	$apps[$x]['menu'][$y]['uuid'] = "29295c90-b1b9-440b-9c7E-c8363c6e8975";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/call_block/call_block.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";
	$apps[$x]['menu'][$y]['groups'][] = "admin";
	$apps[$x]['menu'][$y]['groups'][] = "user";

?>
