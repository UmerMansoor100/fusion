<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Click to Call";
	$apps[$x]['menu'][$y]['title']['en-gb'] = "Click to Call";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Click to Call";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Click to Call";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Pulse para Llamar";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Cliquez pour Appeller";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Clicca e Chiama";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "Klik voor oproep";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Clicar para Chamadas";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Вызов по клику";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "";
	$apps[$x]['menu'][$y]['uuid'] = "f862556f-9ddd-2697-fdf4-bed08ec63aa5";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/click_to_call/click_to_call.php";

?>
