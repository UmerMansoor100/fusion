<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Conferences";
	$apps[$x]['menu'][$y]['title']['en-gb'] = "Conferences";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Konferenzen";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Konferenzen";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Conferencias";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Conférences";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Conferenze";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "Conferenties";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Conferencias";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Конференции";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "";
	$apps[$x]['menu'][$y]['uuid'] = "9f2a8c08-3e65-c41c-a716-3b53d42bc4d4";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/conferences/conferences.php";
	$apps[$x]['menu'][$y]['groups'][] = "admin";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>
