<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Variables";
	$apps[$x]['menu'][$y]['title']['en-gb'] = "Variables";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Variablen";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Variablen";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Variables";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Variables";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Variabili";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "Variabelen";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Zmienne";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Variáveis";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Variáveis";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Параметры FreeSwitch";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Variabler";
	$apps[$x]['menu'][$y]['uuid'] = "7a4e9ec5-24b9-7200-89b8-d70bf8afdd8f";
	$apps[$x]['menu'][$y]['parent_uuid'] = "594d99c5-6128-9c88-ca35-4b33392cec0f";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/vars/vars.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>
