<?php

$array['dashboard'][$x]['dashboard_uuid'] = '6ad0e056-bf3d-465a-956d-bd77d513ab36';
$array['dashboard'][$x]['dashboard_name'] = 'Missed Calls';
$array['dashboard'][$x]['dashboard_path'] = 'app/xml_cdr/resources/dashboard/missed_calls.php';
$array['dashboard'][$x]['dashboard_order'] = '40';
$array['dashboard'][$x]['dashboard_enabled'] = 'true';
$array['dashboard'][$x]['dashboard_description'] = 'Show number and list of calls that were missed.';
$y = 0;
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_group_uuid'] = '85573555-7e18-4449-aa59-a264a7addda9';
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_uuid'] = '6ad0e056-bf3d-465a-956d-bd77d513ab36';
$array['dashboard'][$x]['dashboard_groups'][$y]['group_name'] = 'superadmin';
$y++;
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_group_uuid'] = 'cde35063-58ca-4cdd-94fa-a1c4ee03e66c';
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_uuid'] = '6ad0e056-bf3d-465a-956d-bd77d513ab36';
$array['dashboard'][$x]['dashboard_groups'][$y]['group_name'] = 'admin';
$y++;
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_group_uuid'] = 'b6e6c697-5351-484c-808d-884589c6d527';
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_uuid'] = '6ad0e056-bf3d-465a-956d-bd77d513ab36';
$array['dashboard'][$x]['dashboard_groups'][$y]['group_name'] = 'user';


$x++;
$array['dashboard'][$x]['dashboard_uuid'] = 'c323e296-b1cf-42ea-9c57-fc00697915b7';
$array['dashboard'][$x]['dashboard_name'] = 'Recent Calls';
$array['dashboard'][$x]['dashboard_path'] = 'app/xml_cdr/resources/dashboard/recent_calls.php';
$array['dashboard'][$x]['dashboard_order'] = '60';
$array['dashboard'][$x]['dashboard_enabled'] = 'true';
$array['dashboard'][$x]['dashboard_description'] = 'List of recent calls.';
$y = 0;
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_group_uuid'] = '976018d2-ed21-4ccd-a95c-ef7e36c1134e';
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_uuid'] = 'c323e296-b1cf-42ea-9c57-fc00697915b7';
$array['dashboard'][$x]['dashboard_groups'][$y]['group_name'] = 'superadmin';
$y++;
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_group_uuid'] = '62e53c42-aa15-4a4a-abf0-fb8cd37bafad';
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_uuid'] = 'c323e296-b1cf-42ea-9c57-fc00697915b7';
$array['dashboard'][$x]['dashboard_groups'][$y]['group_name'] = 'admin';
$y++;
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_group_uuid'] = 'a923b923-f1c9-4244-abfd-132c5a2f5b6e';
$array['dashboard'][$x]['dashboard_groups'][$y]['dashboard_uuid'] = 'c323e296-b1cf-42ea-9c57-fc00697915b7';
$array['dashboard'][$x]['dashboard_groups'][$y]['group_name'] = 'user';

?>
