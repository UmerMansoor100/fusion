<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Gateways";
	$apps[$x]['menu'][$y]['title']['en-gb'] = "Gateways";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "البوابات";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Gateways";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Gateways";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Pasarelas";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "Pasarelas";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Passerelles";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Gateways";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "Gateways";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Brama wyjściowa ";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Troncos";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Gateways";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Шлюзы";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Gateways";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Шлюзи";
	$apps[$x]['menu'][$y]['uuid'] = "237a512a-f8fe-1ce4-b5d7-e71c401d7159";
	$apps[$x]['menu'][$y]['parent_uuid'] = "bc96d773-ee57-0cdd-c3ac-2d91aba61b55";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/gateways/gateways.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>
